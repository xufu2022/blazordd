﻿namespace FluxorDemo.Actions;

public record FetchTodosAction();
