﻿namespace FluxorDemo.Actions;

public record ToggleTodoAction(Guid TodoId);
