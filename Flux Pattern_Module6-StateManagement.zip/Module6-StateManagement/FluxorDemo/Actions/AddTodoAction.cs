﻿namespace FluxorDemo.Actions;

public record AddTodoAction(string Text);
