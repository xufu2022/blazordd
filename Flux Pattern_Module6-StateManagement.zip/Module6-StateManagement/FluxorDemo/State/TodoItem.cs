﻿namespace FluxorDemo.State;

public record TodoItem(Guid Id, string Text, bool IsCompleted);
