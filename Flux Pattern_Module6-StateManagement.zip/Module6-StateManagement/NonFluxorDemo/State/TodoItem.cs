﻿namespace NonFluxorDemo.State;

public record TodoItem(Guid Id, string Text, bool IsCompleted);
