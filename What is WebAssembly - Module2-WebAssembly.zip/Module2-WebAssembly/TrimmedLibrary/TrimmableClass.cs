﻿using System.Diagnostics.CodeAnalysis;

namespace TrimmedLibrary;

public class TrimmableClass
{
     public string GetMessage() => "This message comes from the TrimmedLibrary";
}
