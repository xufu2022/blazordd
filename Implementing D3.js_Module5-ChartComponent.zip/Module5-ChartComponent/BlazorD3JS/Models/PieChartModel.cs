﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorD3JS.Models;

public class PieChartModel
{
    public required string Name { get; set; }
    public required int Value { get; set; }
}