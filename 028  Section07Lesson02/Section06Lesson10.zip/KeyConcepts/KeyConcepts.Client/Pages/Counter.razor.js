export function displayCount(count) {
    alert('The count is ' + count);
}

export function createMessage(count) {
    return 'The count is ' + count;
}