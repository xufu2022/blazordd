﻿namespace DependencyLibrary
{
    public interface IDemoDependency
    {
        string GiveRandomNumber();
    }
}